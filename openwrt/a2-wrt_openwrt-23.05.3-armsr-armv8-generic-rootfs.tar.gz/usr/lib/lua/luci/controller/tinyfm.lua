-- /usr/lib/lua/luci/controller/tinyfm.lua
module("luci.controller.tinyfm", package.seeall)
function index()
entry({"admin","services","tinyfm"}, template("tinyfm"), _("File Manager"), 89).leaf=true
end
